package ramakrishna.movierating

class Rating {
    var movieName: String = ""
    var rating: Float = 0.0f
    var comments: String = ""
    var wouldRecommend: Boolean = false
}
